#newpage
the new content of the new page